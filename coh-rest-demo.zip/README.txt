
Requirements:
1. Install JDK 8
2. Install WLS 12c (12.2.1)


Steps:
1a. Rename startWebLogic.cmd.FIXME to startWebLogic.cmd (for windows)
1b. Rename startWebLogic.sh.FIXME to startWebLogic.sh (for Linux)
2.  Update startWebLogic.cmd and startWebLogic.sh to match your directory/environment (MW_HOME and JAVA_HOME)
3.  Run startWeblogic.[sh|cmd]


Try the following url on a browser:


REST operations




URL#1:

http://localhost:7001/my-demo-app-war/rest/Person/1.json
{"age":10,"id":1,"name":"Foo10"}


URL#2:

http://localhost:7001/my-demo-app-war/rest/Person/2.xml
<person>
<age>20</age>
<id>2</id>
<name>Foo20</name>
</person>


URL#3:
http://localhost:7001/my-demo-app-war/rest/Person/2;p=name
<person>
<name>Foo20</name>
</person>



URL#4:
http://localhost:7001/my-demo-app-war/rest/Person
<collection>
<person>
<age>20</age>
<id>2</id>
<name>Foo20</name>
</person>
<person>
<age>10</age>
<id>1</id>
<name>Foo10</name>
</person>
<person>
<age>30</age>
<id>3</id>
<name>Foo30</name>
</person>
<person>
<age>40</age>
<id>4</id>
<name>Foo40</name>
</person>
<person>
<age>50</age>
<id>5</id>
<name>Foo50</name>
</person>
</collection>

Question: With URL#4, do you see similar output or missing some entries? Why? 
Hint: Try URL#1 with other values such as 3.json or 4.json and try again with URL#4
