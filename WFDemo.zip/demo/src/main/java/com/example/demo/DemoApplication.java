package com.example.demo;

import static com.tangosol.util.Filters.like;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.CoherenceSession;
import com.tangosol.net.DefaultCacheServer;
import com.tangosol.net.NamedCache;
import com.tangosol.net.Session;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;


@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
	
	static Map<Integer, Customer> customer = new LinkedHashMap<>();

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		
		String[] myargs = new String[]{"example-config.xml", "5"};
		DefaultCacheServer.main(myargs);
		
	}
	
	public void run(String... strings) throws Exception {
		
		Session mysession = new CoherenceSession();
			
		NamedCache<Object, Object> cache = mysession.getCache("hello-example");	
		
		//cache.truncate();
		
		//
				
		System.out.println("Cache Size (before) => " + cache.size());
		
		/**
		
		customer.put(1, new Customer(1,"Home Depot"));
		customer.put(2, new Customer(2,"MetLife"));
		customer.put(3, new Customer(3,"APPLE"));
		customer.put(4, new Customer(4, "Oracle"));
		
	    cache.putAll(customer);
	    
	    **/
	    
	    
		cache.put(1, new Customer(1,"Home Depot"));
		cache.put(2, new Customer(2,"MetLife"));
		cache.put(3, new Customer(3,"APPLE"));
		cache.put(4, new Customer(4, "Oracle"));	
						
	
		
		cache.forEach((k, v) -> System.out.println("Lambda #1 " + ((Customer)v).getName()));
		
		
		cache.forEach(like(Customer::getName, "H%"), (k, v) -> System.out.println("Filter example " + v));
				
		Customer mycustomer = new Customer(5,"Tiaa");
		
		cache.put(5,mycustomer); 
	
		
		System.out.println("Cache Size (after) => " + cache.size());
		
		
		IntStream.range(1, 5).forEach(key -> System.out.println(cache.get(key)));
		
			
		cache.invokeAll(like(Customer::getName, "T%"), entry -> {
			Customer c = (Customer) entry.getValue();
			c.setName(c.getName().toUpperCase());
			entry.setValue(c);
			return null;
		});
		
		ValueExtractor<Customer, String> name = Customer::getName;
		
		Filter filter = like(Customer::getName, "T%");

		//Set results = cache.entrySet(like(name, "T%"));		
		
		//results.forEach(e -> System.out.println(e));
		Long count = cache.stream(filter)
				         .count();
		
		System.out.println("Count of (T) Customers "+ count);
		
		
		
		mysession.close();
				
	}
}
