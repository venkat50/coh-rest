package com.example.demo;

import com.tangosol.net.cache.CacheStore;
import com.tangosol.util.Base;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MyCacheStore

		extends Base implements CacheStore {

	protected Connection m_con;
	protected String m_sTableName;
	private static final String DB_DRIVER = "org.apache.derby.jdbc.ClientDriver";
	private Customer customer;
	
	//private static final String DB_USERNAME = "app";
	//private static final String DB_PASSWORD = "app";
	private static final String DB_URL = "jdbc:derby://localhost:1527/sample;create=true;user=app;password=app";

	public MyCacheStore(String sTableName) {
		m_sTableName = sTableName;
		
		//System.out.println("TABLE => "+ m_sTableName);
		
		customer = new Customer(0,"TEST");

		configureConnection();
	}

	protected void configureConnection() {
		try {
			Class.forName(DB_DRIVER).newInstance();
			m_con = DriverManager.getConnection(DB_URL);
		
		} catch (Exception e) {
			throw ensureRuntimeException(e, "Connection failed");
		}
	}

	public String getTableName() {
		return m_sTableName;
	}

	public Connection getConnection() {
		return m_con;
	}

	public Customer load(Object oKey) {
		Customer oValue = null;
		String  name = null;
		Connection con = getConnection();
		String sSQL = "SELECT id, NAME FROM " + getTableName() + " WHERE id = ?";
		try {
			PreparedStatement stmt = con.prepareStatement(sSQL);

			stmt.setString(1, String.valueOf(oKey));
			//System.out.println("DEBUG LOAD: "+ stmt);
			ResultSet rslt = stmt.executeQuery();
			if (rslt.next()) {
				name = rslt.getString(2);
				customer.setId((int)oKey);
				customer.setName(name);
				oValue = customer;
				if (rslt.next()) {
					throw new SQLException("Not a unique key: " + oKey);
				}
			}
			stmt.close();
		} catch (SQLException e) {
			throw ensureRuntimeException(e, "Load failed: key=" + oKey);
		}
		
		return oValue;
	}

	public void store(Object oKey, Object oValue) {
		Connection con = getConnection();
		String sTable = getTableName();
		String sSQL;
		
		Customer cust = (Customer) oValue;
		
		//System.out.println("DEBUG STORE =>" + cust.getId() +","+ cust.getName());
		
		if (load(oKey) != null) {
			
			//System.out.println("UPDATE "+ oKey);

			sSQL = "UPDATE " + sTable + " SET NAME = ? where id = ?";
						
		} else {

			//System.out.println("INSERT "+ oKey);
			sSQL = "INSERT INTO " + sTable + " (NAME, id) VALUES (?,?)";
		}
		try {
			PreparedStatement stmt = con.prepareStatement(sSQL);
			int i = 0;
			//stmt.setString(++i, String.valueOf(oValue));
			//stmt.setString(++i, String.valueOf(oKey));
			stmt.setString(++i, cust.getName());
			stmt.setString(++i, String.valueOf(oKey) );

			 
			stmt.executeUpdate();
			
			stmt.close();
		} catch (SQLException e) {
			throw ensureRuntimeException(e, "Store failed: key=" + oKey);
		}
	}

	public void erase(Object oKey) {
		Connection con = getConnection();
		
		//System.out.println("DEBUG DELETE");
		String sSQL = "DELETE FROM " + getTableName() + " WHERE id=?";
		try {
			PreparedStatement stmt = con.prepareStatement(sSQL);

			stmt.setString(1, String.valueOf(oKey));
			stmt.executeUpdate();
			stmt.close();
		} catch (SQLException e) {
			throw ensureRuntimeException(e, "Erase failed: key=" + oKey);
		}
	}

	public void eraseAll(Collection colKeys) {
		throw new UnsupportedOperationException();
	}

	public Map loadAll(Collection colKeys) {
		throw new UnsupportedOperationException();
	}

	public void storeAll(Map mapEntries) {
		throw new UnsupportedOperationException();
	}

	public Iterator keys() {
		Connection con = getConnection();
		String sSQL = "SELECT id FROM " + getTableName();
		List list = new LinkedList();

		try {
			PreparedStatement stmt = con.prepareStatement(sSQL);
			ResultSet rslt = stmt.executeQuery();
			while (rslt.next()) {
				Object oKey = rslt.getString(1);
				list.add(oKey);
			}
			stmt.close();
		} catch (SQLException e) {
			throw ensureRuntimeException(e, "Iterator failed");
		}

		return list.iterator();
	}

}
